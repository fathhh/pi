const router = require('koa-router')()
router.prefix('/archive')
const helper = require('./../interface.js')

router.get('/', async (ctx, next) => {
    let title = '首页'
    let id = ctx.session.id || null;
    let tag = 'archive'
    let cache = await helper.getList()
    await ctx.render('default', {
        title,
        id,
        tag,
        cache
    })
})

module.exports = router