#!/bin/bash -
export NODE_PATH=/home/pi/ws/node_modules
cd /home/pi/ws
/usr/bin/nodejs main.js
